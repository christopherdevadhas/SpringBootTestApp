import { Component, OnInit } from '@angular/core';
import { SampleService } from './project-component.service';
import { ProjectDetail } from './project';

@Component({
  selector: 'app-project-component',
  templateUrl: './project-component.component.html',
  styleUrls: ['./project-component.component.css'],
   providers: [ SampleService ]
})
export class ProjectComponentComponent implements OnInit {
smpls:string[];
inputtext=null;
sample=null
data:Array<ProjectDetail>=[];
newProject : ProjectDetail;

  constructor(private sm: SampleService) {
    this.newProject = new ProjectDetail();
	
    }
    clickAction()
{
	this.sample=this.inputtext
}
getProject()
{
	this.sm.getProject().subscribe(response => {
    console.log(response);
    this.data =response;
    
  });
}

  ngOnInit() {
  }
  addMore()
  {
    
    this.sm.addProject(this.newProject).subscribe(response => {
      console.log(response);
      console.log(this.data);
      this.data.push(response);
      console.log(this.data);
    });
	  
}
}
