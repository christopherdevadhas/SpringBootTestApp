import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProjectDetail } from './project';


@Injectable()
export class SampleService{
	apiAddress:string;
	data:Array<ProjectDetail> = [];
	constructor(private http: HttpClient) { 
	
	this.apiAddress='http://localhost:8080/projectdetails/projects/';
	}


getProject() {
 
   return this.http.get<Array<ProjectDetail>>(this.apiAddress);
   
}

addProject(projectDetail : ProjectDetail){
	return this.http.post<ProjectDetail>(this.apiAddress, projectDetail);
}
}