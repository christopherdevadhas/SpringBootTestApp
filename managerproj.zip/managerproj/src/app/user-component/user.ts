
export class UserDetail {
user_id: number;
employee_id: number;
project_id: number;
task_id: number;
first_name: string;
last_name: string;
}

