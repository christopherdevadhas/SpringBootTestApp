import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserDetail } from './user';


@Injectable()
export class SampleService{
	apiAddress:string;
	data:Array<UserDetail> = [];
	constructor(private http: HttpClient) { 
	
	this.apiAddress='http://localhost:8080/userdetails/users/';
	}


getUser() {
 
   return this.http.get<Array<UserDetail>>(this.apiAddress);
   
}

addUser(userDetail : UserDetail){
	return this.http.post<UserDetail>(this.apiAddress, userDetail);
}
}