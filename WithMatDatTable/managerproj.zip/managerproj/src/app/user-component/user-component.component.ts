import { Component, OnInit } from '@angular/core';
import { SampleService } from './user-component.service';
import { UserDetail } from './user';

@Component({
  selector: 'app-user-component',
  templateUrl: './user-component.component.html',
  styleUrls: ['./user-component.component.css'],
  providers: [ SampleService ]
})
export class UserComponentComponent implements OnInit {
smpls:string[];
inputtext=null;
sample=null
data:Array<UserDetail>=[];
newUser : UserDetail;

  constructor(private sm: SampleService) {
    this.newUser = new UserDetail();
	
    }
    clickAction()
{
	this.sample=this.inputtext
}
getUser()
{
	this.sm.getUser().subscribe(response => {
    console.log(response);
    this.data =response;
    
  });
}

  ngOnInit() {
  }
  addMore()
  {
    
    this.sm.addUser(this.newUser).subscribe(response => {
      console.log(response);
      console.log(this.data);
      this.data.push(response);
      console.log(this.data);
    });
	  
}
}
