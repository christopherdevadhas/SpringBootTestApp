
export class TaskDetail {
task_id: number;
parent_id: number;
project_id: number;
task: string;
priority: string;
status: string;
}

