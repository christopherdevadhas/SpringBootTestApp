import { Component, OnInit, ViewChild } from '@angular/core';
import { SampleService } from './task-component.service';
import { TaskDetail } from './task';
import { MatSort, MatSortable, MatTableDataSource} from '@angular/material';


@Component({
  selector: 'app-task-component',
  templateUrl: './task-component.component.html',
  styleUrls: ['./task-component.component.css'],
   providers: [ SampleService ]
})
export class TaskComponentComponent implements OnInit {
smpls:string[];
inputtext=null;
sample=null
data:Array<TaskDetail>=[];
newTask : TaskDetail;
displayedColumns=['task_id', 'parent_id', 'project_id', 'task', 'priority', 'status'];
@ViewChild(MatSort) sort: MatSort;
dataSource;
  constructor(private sm: SampleService) {
    this.newTask = new TaskDetail();
	
    }
    clickAction()
{
	this.sample=this.inputtext
}
getTask()
{
	this.sm.getTask().subscribe(response => {
    console.log(response);
    this.data =response;
    console.log(this.data);
    this.dataSource = new MatTableDataSource(response);
    this.dataSource.sort=this.sort;
  });
}

  ngOnInit() {
  this.getTask();
  }
  addMore()
  {
    
    this.sm.addTask(this.newTask).subscribe(response => {
      console.log(response);
      console.log(this.data);
      this.data.push(response);
      console.log(this.data);
      this.getTask();
    });
	  
}
}
