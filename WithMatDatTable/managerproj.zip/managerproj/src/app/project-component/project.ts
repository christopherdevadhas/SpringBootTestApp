
export class ProjectDetail {
project_id: number;
project: string;
priority: string;
end_date: string;
start_date: string;
}

